class History {
    constructor() { }


    goBack() {
        history.back()
    }
}
export default History;